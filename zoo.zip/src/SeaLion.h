#pragma once
#include "Mammal.h"
class SeaLion :
	public Mammal
{
public:
	SeaLion();
	SeaLion(int tempNurse);
};


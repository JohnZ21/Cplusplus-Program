#pragma once
#include "Oviparous.h"
class Crocodile :
	public Oviparous
{
public:
	Crocodile();
	Crocodile(int tempEggs);

};


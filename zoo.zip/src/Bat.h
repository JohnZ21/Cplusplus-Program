#pragma once
#include "Mammal.h"
class Bat :
	public Mammal
{

public:
	Bat();
	Bat(int tempNurse);
};


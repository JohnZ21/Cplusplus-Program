#pragma once
#include "Oviparous.h"
class Pelican :
	public Oviparous
{
public:
	Pelican();
	Pelican(int tempEggs);
};


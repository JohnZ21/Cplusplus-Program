#include "SeaLion.h"

SeaLion::SeaLion()
{
	subType = "SeaLion";
}

SeaLion::SeaLion(int tempNurse)
	:Mammal(tempNurse)
{
	subType = "SeaLion";
}

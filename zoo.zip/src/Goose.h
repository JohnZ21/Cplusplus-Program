#pragma once
#include "Oviparous.h"
class Goose :
	public Oviparous
{
public:

	Goose();
	Goose(int tempEggs);
};


#pragma once
#include "Mammal.h"
class Whale :
	public Mammal
{
public:
	Whale();
	Whale(int tempNurse);
};

